import json, statistics as st, numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':8,'axes.titlesize':8,'axes.labelsize':8,'legend.fontsize':7,
  'xtick.labelsize':7,'ytick.labelsize':7,'font.family':'DejaVu Sans','axes.spines.top':False,
  'axes.spines.right':False,'axes.linewidth':0.6,'pdf.fonttype':42})
OUT='figures/'
N=[50,100,500,1000,2000,3000,5000,6000]
C={'BIC tree':('#0072B2','o'),'SHAP tree':('#D55E00','s'),'BIC-HC':('#009E73','^')}
W,H=3.3,2.25
def base(ax,ylabel):
    ax.set_xticks(range(len(N))); ax.set_xticklabels([str(n) for n in N])
    ax.set_xlim(-0.4,len(N)-0.6); ax.set_xlabel('Sample size $n$'); ax.set_ylabel(ylabel)
    ax.grid(True,color='#e3e3e3',lw=0.5); ax.set_axisbelow(True)
def plot(ax,name,means,stds,points=None):
    col,mk=C[name]; x=np.arange(len(N),dtype=float)
    if points:
        for xi,ps in zip(range(len(N)),points):
            ax.scatter([xi+np.random.uniform(-.12,.12) for _ in ps],ps,s=6,color=col,alpha=.25,lw=0)
    ax.errorbar(x,means,yerr=stds,color=col,marker=mk,ms=4.5,lw=1.4,capsize=2,elinewidth=0.8,label=name,
                markeredgecolor='white',markeredgewidth=0.6)
def save(fig,name): fig.tight_layout(pad=0.3); fig.savefig(OUT+name,bbox_inches='tight'); plt.close(fig)
np.random.seed(0)
# RQ1 KL
kl1={'BIC tree':([4.2392,2.5837,1.1670,1.0624,0.6950,0.7063,0.4796,0.7177],[0.3382,0.3184,0.1951,0.2127,0.0868,0.1320,0.0901,0.1141]),
     'SHAP tree':([5.3127,3.1528,1.0682,0.8663,0.7286,0.7304,0.6753,0.6502],[0.4396,0.4040,0.1396,0.2542,0.2301,0.1949,0.1642,0.1728])}
fig,ax=plt.subplots(figsize=(W,H)); base(ax,'KL divergence (nats)')
for k,(m,s) in kl1.items(): plot(ax,k,m,s)
ax.legend(frameon=False); save(fig,'rq1_kl.pdf')
# RQ1 SHD (per-GT)
for cell,fname,yl in [(5,'rq1_skel.pdf','Skeleton SHD'),(4,'rq1_dir.pdf','Directed SHD')]:
    d=json.load(open(f'scripts/rq1_shd_cell{cell}.json'))
    fig,ax=plt.subplots(figsize=(W,H)); base(ax,yl)
    for key,name in [('BIC_Kruskal','BIC tree'),('SHAP_DAG','SHAP tree')]:
        pts=[[v for _,v in d[f'{key}|{n}']] for n in N]
        plot(ax,name,[st.mean(p) for p in pts],[st.stdev(p) for p in pts],pts)
    ax.legend(frameon=False); save(fig,fname)
# RQ2
r=json.load(open('scripts/rq2_seeds.json'))
for key,fname,yl in [('kl','rq2_kl.pdf','KL divergence to ALARM (nats)'),('shd','rq2_dir.pdf','Directed SHD to ALARM')]:
    fig,ax=plt.subplots(figsize=(W,H)); base(ax,yl)
    for m,name in [('BIC','BIC tree'),('SHAPLEY','SHAP tree'),('HC','BIC-HC')]:
        pts=[r[key][f'{m}|{n}'] for n in N]
        plot(ax,name,[st.mean(p) for p in pts],[st.stdev(p) for p in pts],pts)
    ax.legend(frameon=False,ncol=3,loc='upper center',bbox_to_anchor=(0.5,1.13)); save(fig,fname)
skel={'BIC tree':([41.8,31.2,21.2,20.0,20.2,20.0,20.2,20.0],[3.7,5.3,1.9,1.3,0.6,0.0,0.6,0.0]),
      'SHAP tree':([55.6,44.8,28.6,20.8,16.4,15.4,15.8,15.4],[5.2,6.6,4.7,3.6,1.8,2.3,2.2,1.6]),
      'BIC-HC':([36.3,30.6,20.3,15.1,14.5,12.7,13.6,13.5],[3.3,2.8,4.3,2.4,2.6,1.7,2.2,2.6])}
fig,ax=plt.subplots(figsize=(W,H)); base(ax,'Skeleton SHD to ALARM')
for k,(m,s) in skel.items(): plot(ax,k,m,s)
ax.axhline(10,color='#777',lw=0.8,ls='--'); ax.set_ylim(6,63); ax.text(-0.3,7.2,'tree floor: 10 forced deletions',fontsize=6.5,color='#555')
ax.legend(frameon=False,ncol=3,loc='upper center',bbox_to_anchor=(0.5,1.13)); save(fig,'rq2_skel.pdf')

# ---- CPT degrees of freedom (from notebook DoF cells) ----
dofA={'BIC tree':([90.2,93.9,102.5,106.0,98.6,100.3,95.3,100.9],[5.85,6.84,8.00,11.09,4.60,8.76,5.68,6.26]),
      'SHAP tree':([145.9,126.6,102.1,106.0,101.6,106.6,103.8,102.3],[22.23,22.08,3.55,9.17,9.91,7.80,10.95,10.90])}
dofB={'BIC tree':([99.2,105.2,101.5,95.5,104.5,112.5,116.2,107.9],[10.80,15.32,8.81,7.49,14.36,16.28,19.16,9.93]),
      'SHAP tree':([295.3,125.1,107.7,103.9,99.9,94.0,93.9,91.7],[316.27,39.31,9.93,12.25,8.48,4.00,2.64,1.06])}
for dd,fname in [(dofA,'dof_pairwise.pdf'),(dofB,'dof_expert.pdf')]:
    fig,ax=plt.subplots(figsize=(W,H)); base(ax,'Total CPT degrees of freedom')
    for k,(m,s) in dd.items():
        m=list(m); s=list(s)
        if fname=='dof_expert.pdf' and k=='SHAP tree':
            ax.annotate('SHAP tree at n=50:\n295 $\\pm$ 316 (off scale)',xy=(0,179),xytext=(0.12,160),fontsize=6.5,color='#555',
                        arrowprops=dict(arrowstyle='->',color='#777',lw=0.6))
            m[0]=float('nan'); s[0]=0
        plot(ax,k,m,s)
    ax.set_ylim(80,180)
    ax.legend(frameon=False); save(fig,fname)
