# SHAP vs score-based dependency trees (Elsevier cas-dc)

Build (Overleaf or local):  pdflatex main && bibtex main && pdflatex main && pdflatex main

- main.tex          front matter, abstract, highlights, keywords; \input of all sections
- sections/         introduction, related, method, setup, results, discussion, conclusion, endmatter
- figures/          all figures as vector PDFs (+ nomogram jpg)
- scripts/          make_figs.py regenerates the plots (run from this folder); alarm.dot -> `dot -Tpdf scripts/alarm.dot -o figures/alarm_network.pdf`
- references.bib    bibliography (cas-model2-names.bst)

Before submission, fill the placeholders: \repourl and \suppurl in main.tex, funder,
lab name and AI declaration in sections/endmatter.tex (search for TODO).
